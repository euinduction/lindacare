insert into userinfo
values('1','Ashish','EUR', 'GBP', '1000','747','0.7471','24-JAN-15 10:27:44','FR');

insert into userinfo
values('2','Neha','EUR', 'USD', '1000','747','0.7471','24-JAN-15 10:27:44','FR');