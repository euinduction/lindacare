DROP TABLE USERINFO;
CREATE TABLE USERINFO(
id INT PRIMARY KEY AUTO_INCREMENT,
userid VARCHAR(255),
currencyfrom VARCHAR(255),
currencyto VARCHAR(255),
amountsell FLOAT,
amountbuy FLOAT,
rate FLOAT,
timeplaced VARCHAR(255),
origincountry VARCHAR(255)
);