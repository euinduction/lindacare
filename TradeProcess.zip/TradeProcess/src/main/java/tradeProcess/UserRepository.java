package tradeProcess;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Userinfo, Long>{

	Optional<Userinfo> findById(long id);
	Optional<Userinfo> deleteById(long id);
}