package tradeProcess;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "userinfo")
public class Userinfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String userid;
	private String currencyfrom;
	private String currencyto;
	private float amountsell;
	private float amountbuy;
	private float rate;
	private String timeplaced;
	private String origincountry;
	
	public Userinfo() {
		super();
	}
	//{"userId": "134256", "currencyFrom": "EUR", "currencyTo": "GBP", "amountSell": 1000,
	//"amountBuy": 747.10, "rate": 0.7471, "timePlaced" : "24-JAN-15 10:27:44", "originatingCountry"
	//: "FR"}
	
	public Userinfo(String userid, String currencyfrom, String currencyto, float amountsell, float amountbuy, float rate,
			String timeplaced, String origincountry) {
		
		this.userid = userid;
		this.currencyfrom = currencyfrom;
		this.currencyto = currencyto;
		this.amountsell = amountsell;
		this.amountbuy = amountbuy;
		this.rate = rate;
		this.timeplaced = timeplaced;
		this.origincountry = origincountry;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCurrencyfrom() {
		return currencyfrom;
	}

	public void setCurrencyfrom(String currencyfrom) {
		this.currencyfrom = currencyfrom;
	}

	public String getCurrencyto() {
		return currencyto;
	}

	public void setCurrencyto(String currencyto) {
		this.currencyto = currencyto;
	}

	public float getAmountsell() {
		return amountsell;
	}

	public void setAmountsell(float amountsell) {
		this.amountsell = amountsell;
	}

	public float getAmountbuy() {
		return amountbuy;
	}

	public void setAmountbuy(float amountbuy) {
		this.amountbuy = amountbuy;
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public String getTimeplaced() {
		return timeplaced;
	}

	public void setTimeplaced(String timeplaced) {
		this.timeplaced = timeplaced;
	}

	public String getOrigincountry() {
		return origincountry;
	}

	public void setOrigincountry(String origincountry) {
		this.origincountry = origincountry;
	}

	@Override
	public String toString() {
		return "Userinfo [id=" + id + ", userid=" + userid + ", currencyfrom=" + currencyfrom + ", currencyto="
				+ currencyto + ", amountsell=" + amountsell + ", amountbuy=" + amountbuy + ", rate=" + rate
				+ ", timeplaced=" + timeplaced + ", origincountry=" + origincountry + "]";
	}
	
	
}