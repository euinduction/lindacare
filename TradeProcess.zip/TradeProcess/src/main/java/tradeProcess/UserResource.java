package tradeProcess;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserResource {

	@Autowired
	private UserRepository userRepository;

	@GetMapping("/finduser")
	public List<Userinfo> retrieveAllStudents() {
		return userRepository.findAll();
	}

	@GetMapping("/user/{id}")
	public Userinfo retrieveUserinfo(@PathVariable long id) {
		Optional<Userinfo> user = userRepository.findById(id);

		if (!user.isPresent())
			throw new UserNotFoundException("id-" + id);

		return user.get();
	}

	@DeleteMapping("/removeuser/{id}")
	public void deleteStudent(@PathVariable long id) {
		userRepository.deleteById(id);
	}

	@PostMapping("/user")
	public ResponseEntity<Object> createUserinfo(@RequestBody Userinfo user) {
		Userinfo savedUser = userRepository.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedUser.getId()).toUri();

		return ResponseEntity.created(location).build();

	}
	
	@PutMapping("/updateuser/{id}")
	public ResponseEntity<Object> updateUserinfo(@RequestBody Userinfo user, @PathVariable long id) {

		Optional<Userinfo> userOptional = userRepository.findById(id);

		if (!userOptional.isPresent())
			return ResponseEntity.notFound().build();

		user.setId(id);
		
		userRepository.save(user);

		return ResponseEntity.noContent().build();
	}
}